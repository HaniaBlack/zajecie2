﻿
namespace PrzykladowaAplikacja.Models
{
    internal class Studia
    {
    }
}
